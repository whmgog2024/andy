
class IF_ID:

    def __init__(self, instruction, incrPC):
        self.instruction = instruction
        self.incrPC = incrPC